
public class Part3 {

	public static void main(String[] args) {
		// Variable declarations
		int grade = 98;
		float price = 7.89f;
		String phone = "(808) 990-5432";
		String firstName = "Martha";
		String lastName = "King";
		
		// Use the variables above to print:
		// Martha King got 98 in the test.
		// The cost of lunch is $7.89
		// Martha's phone number is (808) 990-5432
		System.out.println(firstName + " " +  lastName + " got " + grade + " in the test.");
		System.out.println("The cost of lunch is $" + price);
		System.out.println(firstName + "'s phone number is " + phone);
		
	}

}
